"""
Módulo PERT (Program Evaluation and Review Technique).

Calcula tiempo esperado, varianza y desviación estándar por actividad, así
como los estadísticos del proyecto a lo largo de la ruta crítica.
"""
from __future__ import annotations

import math
from typing import List

import pandas as pd

from . import models
from .models import COL_ID, COL_NOMBRE, COL_O, COL_M, COL_P


def tiempo_esperado(o: float, m: float, p: float) -> float:
    """TE = (O + 4M + P) / 6."""
    return (o + 4.0 * m + p) / 6.0


def varianza(o: float, p: float) -> float:
    """Var = ((P - O) / 6)^2."""
    return ((p - o) / 6.0) ** 2


def calcular_pert(df: pd.DataFrame) -> pd.DataFrame:
    """Devuelve una tabla PERT por actividad.

    Columnas: ID, Actividad, Optimista, Mas_probable, Pesimista,
    Tiempo_esperado, Varianza, Desviacion_estandar.
    """
    dfn = models.normalizar_df(df)
    filas = []
    for _, r in dfn.iterrows():
        te = tiempo_esperado(r[COL_O], r[COL_M], r[COL_P])
        var = varianza(r[COL_O], r[COL_P])
        filas.append(
            {
                COL_ID: r[COL_ID],
                COL_NOMBRE: r[COL_NOMBRE],
                COL_O: r[COL_O],
                COL_M: r[COL_M],
                COL_P: r[COL_P],
                "Tiempo_esperado": round(te, 3),
                "Varianza": round(var, 3),
                "Desviacion_estandar": round(math.sqrt(var), 3),
            }
        )
    return pd.DataFrame(filas)


def estadisticos_ruta(df_pert: pd.DataFrame, ruta_critica: List[str]) -> dict:
    """Media y desviación estándar del proyecto sumando sobre la ruta crítica.

    La duración esperada del proyecto es la suma de los TE de las actividades
    críticas; la varianza del proyecto es la suma de sus varianzas (teoría
    clásica PERT, asumiendo independencia).
    """
    sub = df_pert[df_pert[COL_ID].isin(ruta_critica)]
    media = float(sub["Tiempo_esperado"].sum())
    var_total = float(sub["Varianza"].sum())
    return {
        "media": round(media, 3),
        "varianza": round(var_total, 3),
        "desviacion": round(math.sqrt(var_total), 3) if var_total >= 0 else 0.0,
    }
