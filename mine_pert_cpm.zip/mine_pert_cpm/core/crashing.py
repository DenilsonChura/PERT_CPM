"""
Módulo de optimización tiempo-costo (Crashing).

Ofrece dos enfoques complementarios:

1. ``costo_marginal`` / ``candidatas`` : análisis clásico del costo pendiente
   (slope) por actividad y ranking de candidatas a reducción.
2. ``crash_lp`` : optimización exacta con OR-Tools (GLOP) que encuentra el
   plan de aceleración de mínimo costo para alcanzar una duración objetivo.
3. ``crash_heuristico`` : reducción iterativa (útil para construir la curva
   tiempo-costo completa paso a paso).
"""
from __future__ import annotations

from typing import Dict, List, Optional

import networkx as nx
import pandas as pd

from . import cpm, models
from .models import COL_ID, COL_NOMBRE


def costo_marginal(dur_normal: float, dur_minima: float,
                   costo_normal: float, costo_acelerado: float) -> Optional[float]:
    """Costo por unidad de tiempo reducida (pendiente de crashing).

    Devuelve ``None`` si la actividad no es reducible.
    """
    reduccion = dur_normal - dur_minima
    if reduccion <= 0:
        return None
    return (costo_acelerado - costo_normal) / reduccion


def preparar(df_crash: pd.DataFrame) -> pd.DataFrame:
    """Calcula pendiente y reducción máxima por actividad.

    Requiere columnas: ID, Actividad, Duracion_normal, Duracion_minima,
    Costo_normal, Costo_acelerado, y opcionalmente Predecesoras.
    """
    df = df_crash.copy()
    slopes, max_red = [], []
    for _, r in df.iterrows():
        s = costo_marginal(
            float(r["Duracion_normal"]), float(r["Duracion_minima"]),
            float(r["Costo_normal"]), float(r["Costo_acelerado"]),
        )
        slopes.append(s)
        max_red.append(max(float(r["Duracion_normal"]) - float(r["Duracion_minima"]), 0.0))
    df["Costo_marginal"] = slopes
    df["Reduccion_maxima"] = max_red
    return df


def candidatas(df_crash: pd.DataFrame, ruta_critica: List[str]) -> pd.DataFrame:
    """Actividades críticas reducibles, ordenadas por costo marginal ascendente."""
    df = preparar(df_crash)
    df = df[df[COL_ID].isin(ruta_critica)]
    df = df[df["Costo_marginal"].notna() & (df["Reduccion_maxima"] > 0)]
    return df.sort_values("Costo_marginal").reset_index(drop=True)


def _grafo_desde_crash(df_crash: pd.DataFrame, duraciones: Dict[str, float]) -> nx.DiGraph:
    G = nx.DiGraph()
    ids = set(df_crash[COL_ID].astype(str))
    for _, r in df_crash.iterrows():
        G.add_node(str(r[COL_ID]), duration=float(duraciones[str(r[COL_ID])]))
    for _, r in df_crash.iterrows():
        preds = models.parse_predecesoras(r.get("Predecesoras"))
        for p in preds:
            if p in ids:
                G.add_edge(p, str(r[COL_ID]))
    return G


def _duracion_proyecto(G: nx.DiGraph) -> float:
    orden = list(nx.topological_sort(G))
    EF: Dict[str, float] = {}
    for n in orden:
        es = max((EF[p] for p in G.predecessors(n)), default=0.0)
        EF[n] = es + G.nodes[n]["duration"]
    return max(EF.values(), default=0.0)


def crash_lp(df_crash: pd.DataFrame, duracion_objetivo: float) -> dict:
    """Optimización exacta con OR-Tools (programación lineal, solver GLOP).

    Minimiza el costo total de aceleración sujeto a alcanzar
    ``duracion_objetivo``. Devuelve un diccionario con el estado, el costo
    incremental, la duración lograda y la reducción por actividad.
    """
    from ortools.linear_solver import pywraplp

    df = preparar(df_crash)
    ids = [str(x) for x in df[COL_ID].tolist()]
    dur_normal = {str(r[COL_ID]): float(r["Duracion_normal"]) for _, r in df.iterrows()}
    max_red = {str(r[COL_ID]): float(r["Reduccion_maxima"]) for _, r in df.iterrows()}
    slope = {str(r[COL_ID]): (r["Costo_marginal"] or 0.0) for _, r in df.iterrows()}
    preds = {str(r[COL_ID]): models.parse_predecesoras(r.get("Predecesoras")) for _, r in df.iterrows()}

    solver = pywraplp.Solver.CreateSolver("GLOP")
    if solver is None:
        return {"estado": "sin_solver", "detalle": "GLOP no disponible"}

    INF = solver.infinity()
    # Variables: x_i reducción, s_i tiempo de inicio, T duración
    x = {i: solver.NumVar(0.0, max_red[i], f"x_{i}") for i in ids}
    s = {i: solver.NumVar(0.0, INF, f"s_{i}") for i in ids}
    T = solver.NumVar(0.0, INF, "T")

    for i in ids:
        di = dur_normal[i] - x[i]  # duración acelerada de i
        # Precedencia: s_j >= s_i + d_i
        for p in preds[i]:
            if p in ids:
                solver.Add(s[i] >= s[p] + (dur_normal[p] - x[p]))
        # Fin del proyecto
        solver.Add(T >= s[i] + di)

    solver.Add(T <= duracion_objetivo)

    solver.Minimize(solver.Sum(slope[i] * x[i] for i in ids))
    status = solver.Solve()

    if status not in (pywraplp.Solver.OPTIMAL, pywraplp.Solver.FEASIBLE):
        return {
            "estado": "infactible",
            "detalle": "No se puede alcanzar la duración objetivo con las reducciones disponibles.",
            "duracion_minima_posible": round(_duracion_minima(df), 3),
        }

    reducciones = {i: round(x[i].solution_value(), 3) for i in ids}
    costo_incremental = round(solver.Objective().Value(), 2)
    filas = []
    for _, r in df.iterrows():
        i = str(r[COL_ID])
        filas.append({
            COL_ID: i,
            COL_NOMBRE: r.get(COL_NOMBRE, i),
            "Duracion_normal": dur_normal[i],
            "Reduccion": reducciones[i],
            "Duracion_final": round(dur_normal[i] - reducciones[i], 3),
            "Costo_marginal": slope[i],
            "Costo_incremental": round(slope[i] * reducciones[i], 2),
        })
    return {
        "estado": "optimo",
        "costo_incremental": costo_incremental,
        "duracion_lograda": round(T.solution_value(), 3),
        "tabla": pd.DataFrame(filas),
    }


def _duracion_minima(df: pd.DataFrame) -> float:
    dmin = {str(r[COL_ID]): float(r["Duracion_minima"]) for _, r in df.iterrows()}
    G = _grafo_desde_crash(df, dmin)
    return _duracion_proyecto(G)


def crash_heuristico(df_crash: pd.DataFrame, pasos: int = 999) -> pd.DataFrame:
    """Curva tiempo-costo por reducción iterativa de la actividad crítica más barata.

    En cada iteración recalcula la ruta crítica y reduce en 1 unidad la
    actividad crítica reducible de menor costo marginal, hasta que no queden
    candidatas o se agoten los ``pasos``.
    """
    df = preparar(df_crash)
    dur = {str(r[COL_ID]): float(r["Duracion_normal"]) for _, r in df.iterrows()}
    dmin = {str(r[COL_ID]): float(r["Duracion_minima"]) for _, r in df.iterrows()}
    slope = {str(r[COL_ID]): (r["Costo_marginal"] or float("inf")) for _, r in df.iterrows()}
    costo_base = float(df["Costo_normal"].sum())

    def ruta_actual():
        G = _grafo_desde_crash(df, dur)
        orden = list(nx.topological_sort(G))
        ES, EF, LS, LF = {}, {}, {}, {}
        for n in orden:
            ES[n] = max((EF[p] for p in G.predecessors(n)), default=0.0)
            EF[n] = ES[n] + G.nodes[n]["duration"]
        Dproj = max(EF.values(), default=0.0)
        for n in reversed(orden):
            LF[n] = min((LS[s] for s in G.successors(n)), default=Dproj)
            LS[n] = LF[n] - G.nodes[n]["duration"]
        criticos = [n for n in orden if abs((LS[n] - ES[n])) <= cpm.TOL]
        return criticos, Dproj

    registros = []
    criticos, Dproj = ruta_actual()
    costo_acum = costo_base
    registros.append({"Iteracion": 0, "Duracion": round(Dproj, 3),
                      "Costo_total": round(costo_acum, 2), "Actividad_reducida": "-"})

    for it in range(1, pasos + 1):
        candidatas_it = [
            n for n in criticos
            if dur[n] - dmin[n] > cpm.TOL and slope[n] != float("inf")
        ]
        if not candidatas_it:
            break
        elegida = min(candidatas_it, key=lambda n: slope[n])
        dur[elegida] -= 1.0
        if dur[elegida] < dmin[elegida]:
            dur[elegida] = dmin[elegida]
        costo_acum += slope[elegida]
        criticos, Dproj = ruta_actual()
        registros.append({
            "Iteracion": it, "Duracion": round(Dproj, 3),
            "Costo_total": round(costo_acum, 2), "Actividad_reducida": elegida,
        })

    return pd.DataFrame(registros)
