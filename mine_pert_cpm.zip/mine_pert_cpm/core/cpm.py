"""
Módulo CPM (Critical Path Method).

Realiza el pase hacia adelante y hacia atrás sobre la red de actividades,
calcula holguras total y libre, identifica la ruta crítica y expone el grafo
dirigido (NetworkX) para su visualización.

Convención de nodos: Activity-on-Node (AoN). Cada actividad es un nodo con
atributo ``duration``. Las aristas representan relaciones de precedencia
fin-inicio (FS).
"""
from __future__ import annotations

from typing import Dict, List, Tuple

import networkx as nx
import pandas as pd

from . import models
from .models import COL_ID, COL_NOMBRE

TOL = 1e-6  # tolerancia para considerar holgura ~ 0


def construir_grafo(dfn: pd.DataFrame) -> nx.DiGraph:
    """Construye el DiGraph AoN a partir del DataFrame normalizado."""
    G = nx.DiGraph()
    for _, r in dfn.iterrows():
        G.add_node(
            r[COL_ID],
            duration=float(r["_dur"]),
            nombre=str(r[COL_NOMBRE]),
        )
    ids = set(dfn[COL_ID])
    for _, r in dfn.iterrows():
        for p in r["_preds"]:
            if p in ids and p != r[COL_ID]:
                G.add_edge(p, r[COL_ID])
    return G


def tiene_ciclos(G: nx.DiGraph) -> bool:
    return not nx.is_directed_acyclic_graph(G)


def compute_cpm(df: pd.DataFrame) -> Tuple[pd.DataFrame, List[str], float, nx.DiGraph]:
    """Ejecuta el análisis CPM completo.

    Devuelve una tupla ``(tabla, ruta_critica, duracion_proyecto, grafo)``.

    ``tabla`` incluye: ID, Actividad, Duracion, Inicio_temprano (ES),
    Fin_temprano (EF), Inicio_tardio (LS), Fin_tardio (LF), Holgura_total,
    Holgura_libre y Critica (bool).

    Lanza ``ValueError`` si el grafo contiene dependencias circulares.
    """
    dfn = models.normalizar_df(df)
    G = construir_grafo(dfn)

    if tiene_ciclos(G):
        ciclo = _primer_ciclo(G)
        raise ValueError(f"Dependencias circulares detectadas: {' -> '.join(ciclo)}")

    orden = list(nx.topological_sort(G))

    # Pase hacia adelante
    ES: Dict[str, float] = {}
    EF: Dict[str, float] = {}
    for n in orden:
        preds = list(G.predecessors(n))
        ES[n] = max((EF[p] for p in preds), default=0.0)
        EF[n] = ES[n] + G.nodes[n]["duration"]

    duracion_proyecto = max(EF.values(), default=0.0)

    # Pase hacia atrás
    LS: Dict[str, float] = {}
    LF: Dict[str, float] = {}
    for n in reversed(orden):
        succ = list(G.successors(n))
        LF[n] = min((LS[s] for s in succ), default=duracion_proyecto)
        LS[n] = LF[n] - G.nodes[n]["duration"]

    # Holguras y criticidad
    filas = []
    for n in orden:
        succ = list(G.successors(n))
        holgura_total = LS[n] - ES[n]
        if succ:
            holgura_libre = min(ES[s] for s in succ) - EF[n]
        else:
            holgura_libre = duracion_proyecto - EF[n]
        critica = abs(holgura_total) <= TOL
        filas.append(
            {
                COL_ID: n,
                COL_NOMBRE: G.nodes[n]["nombre"],
                "Duracion": round(G.nodes[n]["duration"], 3),
                "Inicio_temprano": round(ES[n], 3),
                "Fin_temprano": round(EF[n], 3),
                "Inicio_tardio": round(LS[n], 3),
                "Fin_tardio": round(LF[n], 3),
                "Holgura_total": round(holgura_total, 3),
                "Holgura_libre": round(max(holgura_libre, 0.0), 3),
                "Critica": critica,
            }
        )

    tabla = pd.DataFrame(filas)
    ruta = ruta_critica(G, ES, EF, LS)

    # Guardar atributos en el grafo para la visualización
    for n in G.nodes:
        G.nodes[n].update(
            ES=ES[n], EF=EF[n], LS=LS[n], LF=LF[n],
            critica=(abs((LS[n] - ES[n])) <= TOL),
        )

    return tabla, ruta, round(duracion_proyecto, 3), G


def ruta_critica(G: nx.DiGraph, ES: Dict[str, float], EF: Dict[str, float],
                 LS: Dict[str, float]) -> List[str]:
    """Reconstruye una ruta crítica por retroceso desde el nodo de mayor EF."""
    if not G.nodes:
        return []
    # Nodo final: el de mayor Fin_temprano
    fin = max(EF, key=EF.get)
    ruta = [fin]
    actual = fin
    while True:
        preds = list(G.predecessors(actual))
        criticos = [
            p for p in preds
            if abs(EF[p] - ES[actual]) <= TOL and abs((LS[p] - ES[p])) <= TOL
        ]
        if not criticos:
            break
        # Elegir el predecesor de mayor EF (encadena la ruta más larga)
        siguiente = max(criticos, key=EF.get)
        ruta.append(siguiente)
        actual = siguiente
    return list(reversed(ruta))


def aristas_criticas(ruta: List[str]) -> List[Tuple[str, str]]:
    """Pares consecutivos de la ruta crítica (para resaltar aristas)."""
    return list(zip(ruta[:-1], ruta[1:]))


def _primer_ciclo(G: nx.DiGraph) -> List[str]:
    try:
        ciclo = nx.find_cycle(G, orientation="original")
        nodos = [u for u, _v, _d in ciclo]
        nodos.append(ciclo[-1][1])
        return nodos
    except nx.NetworkXNoCycle:
        return []
