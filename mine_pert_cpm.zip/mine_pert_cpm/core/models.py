"""
Modelo de datos central del aplicativo PERT-CPM Minero.

Define la representación canónica de una actividad, los nombres de columna
estandarizados y utilidades de parseo/normalización que el resto de los
módulos consume. Toda la lógica de cálculo trabaja sobre un DataFrame
normalizado para mantener el código simple, tipado y testeable.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

import pandas as pd

# ---------------------------------------------------------------------------
# Nombres de columna estandarizados (los que ve el usuario en el Data Editor)
# ---------------------------------------------------------------------------
COL_ID = "ID"
COL_NOMBRE = "Actividad"
COL_PRED = "Predecesoras"
COL_O = "Optimista"
COL_M = "Mas_probable"
COL_P = "Pesimista"
COL_DUR = "Duracion_CPM"
COL_COSTO = "Costo"
COL_REC = "Recursos"

COLUMNAS = [COL_ID, COL_NOMBRE, COL_PRED, COL_O, COL_M, COL_P, COL_DUR, COL_COSTO, COL_REC]

# Etiquetas amigables (con acentos) para mostrar en tablas de resultados
ETIQUETAS = {
    COL_ID: "ID",
    COL_NOMBRE: "Actividad",
    COL_PRED: "Predecesoras",
    COL_O: "Optimista (O)",
    COL_M: "Más probable (M)",
    COL_P: "Pesimista (P)",
    COL_DUR: "Duración CPM",
    COL_COSTO: "Costo",
    COL_REC: "Recursos",
}


@dataclass
class Actividad:
    """Representación tipada de una actividad del proyecto."""

    id: str
    nombre: str = ""
    predecesoras: List[str] = field(default_factory=list)
    optimista: float = 0.0
    mas_probable: float = 0.0
    pesimista: float = 0.0
    duracion_cpm: Optional[float] = None
    costo: float = 0.0
    recursos: str = ""


def parse_predecesoras(valor) -> List[str]:
    """Convierte el texto de predecesoras en una lista limpia de IDs.

    Acepta separadores por coma, punto y coma o espacios. Devuelve lista vacía
    para valores nulos o cadenas vacías.
    """
    if valor is None:
        return []
    if isinstance(valor, (list, tuple)):
        items = list(valor)
    else:
        texto = str(valor).strip()
        if not texto or texto.lower() in {"nan", "none", "-"}:
            return []
        texto = texto.replace(";", ",").replace("|", ",")
        # Permitir espacios como separador si no hay comas
        if "," not in texto:
            items = texto.split()
        else:
            items = texto.split(",")
    return [str(x).strip() for x in items if str(x).strip()]


def _num(valor, defecto: float = 0.0) -> float:
    """Conversión robusta a float."""
    try:
        if valor is None or (isinstance(valor, float) and pd.isna(valor)):
            return defecto
        return float(valor)
    except (TypeError, ValueError):
        return defecto


def normalizar_df(df: pd.DataFrame) -> pd.DataFrame:
    """Normaliza un DataFrame de actividades para el motor de cálculo.

    Garantiza que existan todas las columnas, calcula columnas auxiliares
    ``_preds`` (lista de predecesoras) y ``_dur`` (duración efectiva usada por
    CPM: la duración CPM si se especificó, de lo contrario el tiempo esperado
    PERT).
    """
    df = df.copy()

    for col in COLUMNAS:
        if col not in df.columns:
            df[col] = None

    # Limpiar filas sin ID
    df[COL_ID] = df[COL_ID].astype(str).str.strip()
    df = df[df[COL_ID].notna() & (df[COL_ID] != "") & (df[COL_ID].str.lower() != "nan")]
    df = df.drop_duplicates(subset=[COL_ID], keep="first").reset_index(drop=True)

    # Numéricos
    for col in (COL_O, COL_M, COL_P, COL_DUR, COL_COSTO):
        df[col] = df[col].apply(_num)

    # Lista de predecesoras
    df["_preds"] = df[COL_PRED].apply(parse_predecesoras)

    # Tiempo esperado PERT (auxiliar) y duración efectiva
    df["_te"] = (df[COL_O] + 4 * df[COL_M] + df[COL_P]) / 6.0

    def _dur_efectiva(row):
        d = row[COL_DUR]
        return float(d) if d and d > 0 else float(row["_te"])

    df["_dur"] = df.apply(_dur_efectiva, axis=1)
    return df


def df_vacio() -> pd.DataFrame:
    """DataFrame vacío con el esquema estándar."""
    return pd.DataFrame({c: pd.Series(dtype="object") for c in COLUMNAS})
