"""
Módulo minero: plantillas de actividades, indicadores (KPIs) y una simulación
de eventos discretos (SimPy) del ciclo de equipos.

Contiene plantillas de proyecto listas para cargar tanto para minería
subterránea (desarrollo, rampas, chimeneas, producción, sostenimiento,
preparación de tajos) como para minería superficial (perforación de bancos,
voladura, carguío, transporte, chancado, botaderos, stockpile).
"""
from __future__ import annotations

from typing import Dict, List

import pandas as pd

from .models import (COL_ID, COL_NOMBRE, COL_PRED, COL_O, COL_M, COL_P,
                     COL_DUR, COL_COSTO, COL_REC, COLUMNAS)


# ---------------------------------------------------------------------------
# Plantillas de actividades
# ---------------------------------------------------------------------------
def _fila(id_, nombre, pred, o, m, p, costo, rec) -> Dict:
    return {COL_ID: id_, COL_NOMBRE: nombre, COL_PRED: pred, COL_O: o, COL_M: m,
            COL_P: p, COL_DUR: 0, COL_COSTO: costo, COL_REC: rec}


PLANTILLA_SUBTERRANEA: List[Dict] = [
    _fila("A", "Topografía y marcado", "", 0.3, 0.5, 1.0, 800, "Topógrafo"),
    _fila("B", "Perforación de frente", "A", 1.5, 2.0, 3.5, 3500, "Jumbo"),
    _fila("C", "Carguío de explosivos", "B", 0.5, 0.8, 1.5, 1200, "Cuadrilla"),
    _fila("D", "Voladura", "C", 0.2, 0.3, 0.5, 900, "Explosivos"),
    _fila("E", "Ventilación", "D", 0.4, 0.6, 1.2, 400, "Ventiladores"),
    _fila("F", "Desatado de rocas", "E", 0.5, 0.8, 1.5, 700, "Scaler"),
    _fila("G", "Sostenimiento (pernos/shotcrete)", "F", 1.0, 1.5, 3.0, 4200, "Robot shotcrete"),
    _fila("H", "Limpieza (mucking)", "F", 1.0, 1.8, 3.0, 2600, "Scoop"),
    _fila("I", "Transporte a superficie", "H", 0.8, 1.2, 2.5, 2200, "Camión bajo perfil"),
    _fila("J", "Preparación de tajo", "G,I", 2.0, 3.0, 5.0, 5000, "Cuadrilla preparación"),
]

PLANTILLA_SUPERFICIAL: List[Dict] = [
    _fila("A", "Desbroce y limpieza de banco", "", 1.0, 1.5, 3.0, 4000, "Tractor D10"),
    _fila("B", "Perforación de bancos", "A", 2.0, 3.0, 5.0, 12000, "Perforadora DTH"),
    _fila("C", "Carguío de explosivos", "B", 0.5, 1.0, 2.0, 6000, "Camión fábrica"),
    _fila("D", "Voladura", "C", 0.2, 0.3, 0.6, 8000, "Explosivos"),
    _fila("E", "Carguío de mineral", "D", 2.0, 3.5, 6.0, 15000, "Pala/Excavadora"),
    _fila("F", "Transporte a chancadora", "E", 2.0, 3.0, 5.0, 18000, "Flota camiones"),
    _fila("G", "Transporte a botadero", "E", 1.5, 2.5, 4.0, 9000, "Flota camiones"),
    _fila("H", "Chancado primario", "F", 1.5, 2.0, 3.5, 7000, "Chancadora"),
    _fila("I", "Gestión de stockpile", "H", 0.5, 1.0, 2.0, 2500, "Cargador frontal"),
    _fila("J", "Conformación de botadero", "G", 1.0, 1.5, 3.0, 3000, "Tractor"),
]


def plantilla_df(tipo: str) -> pd.DataFrame:
    """Devuelve un DataFrame con la plantilla solicitada ('subterranea'|'superficial')."""
    datos = PLANTILLA_SUBTERRANEA if tipo == "subterranea" else PLANTILLA_SUPERFICIAL
    return pd.DataFrame(datos, columns=COLUMNAS)


# ---------------------------------------------------------------------------
# Indicadores (KPIs)
# ---------------------------------------------------------------------------
def kpis_subterranea(metros_perforados: float, guardias: float, avance_guardia: float,
                     disponibilidad: float, utilizacion: float, toneladas: float,
                     equipos: float, dias: float) -> Dict[str, float]:
    """KPIs típicos de minería subterránea."""
    dias = max(dias, 1e-9)
    guardias = max(guardias, 1e-9)
    equipos = max(equipos, 1e-9)
    return {
        "m/dia": round(metros_perforados / dias, 2),
        "t/dia": round(toneladas / dias, 2),
        "t/guardia": round(toneladas / guardias, 2),
        "avance_m_guardia": round(avance_guardia, 2),
        "productividad_equipo_t": round(toneladas / equipos, 2),
        "disponibilidad_%": round(disponibilidad * 100, 1),
        "utilizacion_%": round(utilizacion * 100, 1),
        "efectividad_%": round(disponibilidad * utilizacion * 100, 1),
    }


def kpis_superficial(bcm: float, toneladas: float, horas: float, camiones: float,
                     distancia_km: float, velocidad: float, tiempo_ciclo_min: float,
                     disponibilidad: float, utilizacion: float) -> Dict[str, float]:
    """KPIs típicos de minería superficial (cielo abierto)."""
    horas = max(horas, 1e-9)
    camiones = max(camiones, 1e-9)
    ciclos_hora = 60.0 / tiempo_ciclo_min if tiempo_ciclo_min > 0 else 0.0
    return {
        "BCM/h": round(bcm / horas, 2),
        "t/h": round(toneladas / horas, 2),
        "t/camion": round(toneladas / camiones, 2),
        "ciclos/h": round(ciclos_hora, 2),
        "productividad_flota_t/h": round((toneladas / horas) / camiones, 2),
        "disponibilidad_%": round(disponibilidad * 100, 1),
        "utilizacion_%": round(utilizacion * 100, 1),
        "efectividad_%": round(disponibilidad * utilizacion * 100, 1),
        "velocidad_km/h": round(velocidad, 1),
        "distancia_km": round(distancia_km, 2),
    }


# ---------------------------------------------------------------------------
# Simulación de eventos discretos (SimPy) del ciclo de acarreo
# ---------------------------------------------------------------------------
def simular_ciclo_acarreo(n_camiones: int, capacidad_t: float, t_carga: float,
                          t_viaje_ida: float, t_descarga: float, t_viaje_vuelta: float,
                          n_palas: int, horas_turno: float, semilla: int = 7) -> Dict[str, float]:
    """Simula, con SimPy, el ciclo carguío-acarreo con palas como recurso limitado.

    Los tiempos están en minutos. Devuelve producción total, número de ciclos y
    productividad de la flota durante un turno.
    """
    import random

    import simpy

    random.seed(semilla)
    horizonte = horas_turno * 60.0  # minutos
    estado = {"ciclos": 0, "toneladas": 0.0}

    def camion(env, palas):
        while True:
            # Solicitar pala para carguío
            with palas.request() as req:
                yield req
                yield env.timeout(max(random.gauss(t_carga, t_carga * 0.1), 0.1))
            # Viaje ida
            yield env.timeout(max(random.gauss(t_viaje_ida, t_viaje_ida * 0.15), 0.1))
            # Descarga
            yield env.timeout(max(random.gauss(t_descarga, t_descarga * 0.1), 0.1))
            # Viaje vuelta
            yield env.timeout(max(random.gauss(t_viaje_vuelta, t_viaje_vuelta * 0.15), 0.1))
            estado["ciclos"] += 1
            estado["toneladas"] += capacidad_t

    env = simpy.Environment()
    palas = simpy.Resource(env, capacity=max(int(n_palas), 1))
    for _ in range(max(int(n_camiones), 1)):
        env.process(camion(env, palas))
    env.run(until=horizonte)

    horas = max(horas_turno, 1e-9)
    return {
        "ciclos_totales": estado["ciclos"],
        "toneladas_turno": round(estado["toneladas"], 1),
        "t/h": round(estado["toneladas"] / horas, 2),
        "t/camion": round(estado["toneladas"] / max(n_camiones, 1), 1),
        "productividad_flota_t/h": round((estado["toneladas"] / horas) / max(n_camiones, 1), 2),
    }
