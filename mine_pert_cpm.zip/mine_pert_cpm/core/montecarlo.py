"""
Módulo de simulación Monte Carlo de la duración del proyecto.

Muestrea la duración de cada actividad según una distribución (triangular o
Beta-PERT), recalcula la ruta más larga de la red en cada iteración y construye
la distribución de la duración total del proyecto.
"""
from __future__ import annotations

from typing import Dict, List

import networkx as nx
import numpy as np
import pandas as pd
from scipy import stats

from . import cpm, models
from .models import COL_ID, COL_O, COL_M, COL_P


def _muestrear(o: float, m: float, p: float, n: int, dist: str, rng: np.random.Generator) -> np.ndarray:
    """Genera ``n`` muestras de duración para una actividad."""
    o, m, p = float(o), float(m), float(p)
    if p <= o:  # actividad determinista
        return np.full(n, m if m > 0 else o)
    if dist == "beta":
        # Beta-PERT: media = (O + 4M + P)/6, forma clásica con lambda=4
        alpha = 1 + 4 * (m - o) / (p - o)
        beta_ = 1 + 4 * (p - m) / (p - o)
        return o + stats.beta.rvs(alpha, beta_, size=n, random_state=rng) * (p - o)
    # Triangular (por defecto)
    c = (m - o) / (p - o) if p > o else 0.5
    c = min(max(c, 1e-6), 1 - 1e-6)
    return stats.triang.rvs(c, loc=o, scale=(p - o), size=n, random_state=rng)


def _duracion_red(dfn: pd.DataFrame, duraciones: Dict[str, float]) -> float:
    """Duración del proyecto (ruta más larga) para un set de duraciones."""
    G = cpm.construir_grafo(dfn)
    for n in G.nodes:
        G.nodes[n]["duration"] = duraciones.get(n, G.nodes[n]["duration"])
    orden = list(nx.topological_sort(G))
    EF: Dict[str, float] = {}
    for n in orden:
        es = max((EF[p] for p in G.predecessors(n)), default=0.0)
        EF[n] = es + G.nodes[n]["duration"]
    return max(EF.values(), default=0.0)


def simular(df: pd.DataFrame, n_iter: int = 10000, dist: str = "triangular",
            objetivo: float | None = None, semilla: int = 42) -> dict:
    """Ejecuta la simulación Monte Carlo.

    Devuelve un diccionario con el arreglo de duraciones, percentiles P50/P80/P90,
    media, desviación y la probabilidad de cumplir la fecha objetivo.
    """
    dfn = models.normalizar_df(df)
    ids: List[str] = dfn[COL_ID].tolist()
    rng = np.random.default_rng(semilla)

    # Matriz de muestras (n_iter x n_actividades) — vectorizada por actividad
    muestras: Dict[str, np.ndarray] = {}
    for _, r in dfn.iterrows():
        muestras[r[COL_ID]] = _muestrear(r[COL_O], r[COL_M], r[COL_P], n_iter, dist, rng)

    # Longest path por iteración usando orden topológico fijo
    G = cpm.construir_grafo(dfn)
    orden = list(nx.topological_sort(G))
    EF = {n: np.zeros(n_iter) for n in orden}
    for n in orden:
        preds = list(G.predecessors(n))
        if preds:
            es = np.maximum.reduce([EF[p] for p in preds])
        else:
            es = np.zeros(n_iter)
        EF[n] = es + muestras[n]

    duraciones = np.maximum.reduce([EF[n] for n in orden]) if orden else np.zeros(n_iter)

    p50, p80, p90 = np.percentile(duraciones, [50, 80, 90])
    prob_cumplimiento = None
    if objetivo is not None:
        prob_cumplimiento = float(np.mean(duraciones <= objetivo))

    return {
        "duraciones": duraciones,
        "media": float(np.mean(duraciones)),
        "desviacion": float(np.std(duraciones)),
        "min": float(np.min(duraciones)),
        "max": float(np.max(duraciones)),
        "P50": float(p50),
        "P80": float(p80),
        "P90": float(p90),
        "objetivo": objetivo,
        "prob_cumplimiento": prob_cumplimiento,
        "n_iter": n_iter,
        "dist": dist,
    }
