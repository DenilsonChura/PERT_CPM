"""
Visualización de la red PERT-CPM (Activity-on-Node) con NetworkX + Plotly.

Genera un diagrama interactivo con nodos por actividad, aristas de dependencia,
duración en cada nodo y la ruta crítica resaltada en rojo.
"""
from __future__ import annotations

from typing import List, Tuple

import networkx as nx
import plotly.graph_objects as go


def _layout_por_capas(G: nx.DiGraph) -> dict:
    """Posiciona los nodos por 'niveles' topológicos (izquierda a derecha)."""
    # Nivel = longitud del camino más largo desde una fuente
    nivel = {}
    for n in nx.topological_sort(G):
        preds = list(G.predecessors(n))
        nivel[n] = 0 if not preds else max(nivel[p] for p in preds) + 1

    # Agrupar por nivel y distribuir verticalmente
    capas: dict = {}
    for n, l in nivel.items():
        capas.setdefault(l, []).append(n)

    pos = {}
    for l, nodos in capas.items():
        k = len(nodos)
        for i, n in enumerate(sorted(nodos)):
            y = (k - 1) / 2.0 - i  # centrado
            pos[n] = (l * 2.2, y * 1.6)
    return pos


def figura_red(G: nx.DiGraph, ruta_critica: List[str]) -> go.Figure:
    """Construye la figura Plotly de la red."""
    pos = _layout_por_capas(G)
    criticas: set = set(zip(ruta_critica[:-1], ruta_critica[1:]))
    set_ruta = set(ruta_critica)

    edge_traces = []
    for u, v in G.edges():
        x0, y0 = pos[u]
        x1, y1 = pos[v]
        es_crit = (u, v) in criticas
        edge_traces.append(
            go.Scatter(
                x=[x0, x1, None], y=[y0, y1, None],
                mode="lines",
                line=dict(width=3 if es_crit else 1.4,
                          color="#e63946" if es_crit else "#8d99ae"),
                hoverinfo="none", showlegend=False,
            )
        )
        # Flecha (annotation) se agrega abajo vía layout

    node_x, node_y, textos, hover, colores, bordes = [], [], [], [], [], []
    for n in G.nodes():
        x, y = pos[n]
        node_x.append(x)
        node_y.append(y)
        d = G.nodes[n]
        textos.append(f"<b>{n}</b><br>{d.get('duration', 0):.1f}")
        hover.append(
            f"<b>{n} — {d.get('nombre', '')}</b><br>"
            f"Duración: {d.get('duration', 0):.2f}<br>"
            f"ES: {d.get('ES', 0):.1f} | EF: {d.get('EF', 0):.1f}<br>"
            f"LS: {d.get('LS', 0):.1f} | LF: {d.get('LF', 0):.1f}"
        )
        es_crit = n in set_ruta
        colores.append("#e63946" if es_crit else "#457b9d")
        bordes.append("#9d0208" if es_crit else "#1d3557")

    node_trace = go.Scatter(
        x=node_x, y=node_y, mode="markers+text",
        text=textos, textposition="middle center",
        textfont=dict(color="white", size=11),
        hovertext=hover, hoverinfo="text",
        marker=dict(size=48, color=colores, line=dict(width=2.5, color=bordes),
                    symbol="circle"),
        showlegend=False,
    )

    fig = go.Figure(data=edge_traces + [node_trace])

    # Flechas de dependencia
    for u, v in G.edges():
        x0, y0 = pos[u]
        x1, y1 = pos[v]
        es_crit = (u, v) in criticas
        fig.add_annotation(
            x=x1, y=y1, ax=x0, ay=y0, xref="x", yref="y", axref="x", ayref="y",
            showarrow=True, arrowhead=3, arrowsize=1.2, arrowwidth=1.5,
            arrowcolor="#e63946" if es_crit else "#8d99ae", opacity=0.9,
            standoff=26,
        )

    fig.update_layout(
        title="Red PERT-CPM (ruta crítica en rojo)",
        showlegend=False, hovermode="closest",
        margin=dict(l=20, r=20, t=50, b=20),
        xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
        yaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
        template="plotly_dark", height=520,
    )
    return fig
