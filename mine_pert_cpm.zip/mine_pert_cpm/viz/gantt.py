"""
Diagrama de Gantt interactivo con Plotly.

Convierte los tiempos tempranos del CPM (ES/EF) en fechas de calendario a partir
de una fecha de inicio, y resalta las actividades críticas.
"""
from __future__ import annotations

from datetime import datetime, timedelta

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

from core.models import COL_ID, COL_NOMBRE


def construir_gantt(tabla_cpm: pd.DataFrame, fecha_inicio: datetime,
                    df_actividades: pd.DataFrame | None = None,
                    avance: dict | None = None) -> go.Figure:
    """Genera la figura de Gantt.

    ``tabla_cpm`` proviene de ``core.cpm.compute_cpm``. ``avance`` es un dict
    opcional {ID: porcentaje 0-100}.
    """
    recursos_map = {}
    if df_actividades is not None and COL_ID in df_actividades.columns:
        for _, r in df_actividades.iterrows():
            recursos_map[str(r[COL_ID])] = str(r.get("Recursos", ""))

    filas = []
    for _, r in tabla_cpm.iterrows():
        ini = fecha_inicio + timedelta(days=float(r["Inicio_temprano"]))
        fin = fecha_inicio + timedelta(days=float(r["Fin_temprano"]))
        # Evitar duración cero visual
        if fin <= ini:
            fin = ini + timedelta(hours=6)
        pct = 0
        if avance:
            pct = avance.get(str(r[COL_ID]), 0)
        filas.append({
            "ID": r[COL_ID],
            "Actividad": f"{r[COL_ID]} — {r[COL_NOMBRE]}",
            "Inicio": ini,
            "Fin": fin,
            "Tipo": "Crítica" if r["Critica"] else "No crítica",
            "Recursos": recursos_map.get(str(r[COL_ID]), ""),
            "Avance": pct,
            "Holgura": r["Holgura_total"],
        })

    dfg = pd.DataFrame(filas)
    if dfg.empty:
        return go.Figure()

    dfg = dfg.sort_values("Inicio")

    fig = px.timeline(
        dfg, x_start="Inicio", x_end="Fin", y="Actividad", color="Tipo",
        color_discrete_map={"Crítica": "#e63946", "No crítica": "#457b9d"},
        hover_data={"Recursos": True, "Avance": True, "Holgura": True,
                    "Inicio": True, "Fin": True, "Tipo": False},
    )
    fig.update_yaxes(autorange="reversed")

    # Barras de avance superpuestas
    for _, row in dfg.iterrows():
        if row["Avance"] and row["Avance"] > 0:
            dur = (row["Fin"] - row["Inicio"])
            fin_avance = row["Inicio"] + dur * (row["Avance"] / 100.0)
            fig.add_shape(
                type="rect", xref="x", yref="y",
                x0=row["Inicio"], x1=fin_avance,
                y0=row["Actividad"], y1=row["Actividad"],
                fillcolor="rgba(46, 204, 113, 0.55)", line=dict(width=0),
                layer="above",
            )

    fig.update_layout(
        title="Diagrama de Gantt (fechas tempranas)",
        template="plotly_dark", height=max(360, 34 * len(dfg)),
        margin=dict(l=20, r=20, t=50, b=20),
        legend_title_text="",
    )
    return fig
