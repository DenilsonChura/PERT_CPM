"""Pruebas del núcleo de cálculo (PERT, CPM, crashing, Monte Carlo)."""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pandas as pd

from core import pert, cpm, crashing, montecarlo, mining, models
from io_utils import validation


def caso_clasico():
    # A->B->D->F  y  A->C->E->F  ; ruta crítica esperada A-B-D-F = 14
    data = [
        {"ID": "A", "Actividad": "A", "Predecesoras": "",   "Optimista": 3, "Mas_probable": 3, "Pesimista": 3, "Duracion_CPM": 3, "Costo": 0, "Recursos": ""},
        {"ID": "B", "Actividad": "B", "Predecesoras": "A",  "Optimista": 4, "Mas_probable": 4, "Pesimista": 4, "Duracion_CPM": 4, "Costo": 0, "Recursos": ""},
        {"ID": "C", "Actividad": "C", "Predecesoras": "A",  "Optimista": 2, "Mas_probable": 2, "Pesimista": 2, "Duracion_CPM": 2, "Costo": 0, "Recursos": ""},
        {"ID": "D", "Actividad": "D", "Predecesoras": "B",  "Optimista": 5, "Mas_probable": 5, "Pesimista": 5, "Duracion_CPM": 5, "Costo": 0, "Recursos": ""},
        {"ID": "E", "Actividad": "E", "Predecesoras": "C",  "Optimista": 1, "Mas_probable": 1, "Pesimista": 1, "Duracion_CPM": 1, "Costo": 0, "Recursos": ""},
        {"ID": "F", "Actividad": "F", "Predecesoras": "D,E","Optimista": 2, "Mas_probable": 2, "Pesimista": 2, "Duracion_CPM": 2, "Costo": 0, "Recursos": ""},
    ]
    return pd.DataFrame(data)


def test_pert():
    df = pd.DataFrame([{"ID": "X", "Actividad": "X", "Predecesoras": "",
                        "Optimista": 2, "Mas_probable": 4, "Pesimista": 12,
                        "Duracion_CPM": 0, "Costo": 0, "Recursos": ""}])
    t = pert.calcular_pert(df)
    te = t.iloc[0]["Tiempo_esperado"]
    var = t.iloc[0]["Varianza"]
    assert abs(te - (2 + 16 + 12) / 6) < 1e-3, te      # 5.0
    assert abs(var - ((12 - 2) / 6) ** 2) < 1e-2, var  # 2.777...
    print("test_pert OK  TE=%.3f Var=%.3f" % (te, var))


def test_cpm():
    df = caso_clasico()
    tabla, ruta, dur, G = cpm.compute_cpm(df)
    assert dur == 14, dur
    assert ruta == ["A", "B", "D", "F"], ruta
    criticas = set(tabla[tabla["Critica"]]["ID"])
    assert criticas == {"A", "B", "D", "F"}, criticas
    # Holgura de C y E debe ser 6
    hC = tabla[tabla["ID"] == "C"]["Holgura_total"].iloc[0]
    hE = tabla[tabla["ID"] == "E"]["Holgura_total"].iloc[0]
    assert hC == 6 and hE == 6, (hC, hE)
    # Holgura libre de E = 6, de D = 0
    ffE = tabla[tabla["ID"] == "E"]["Holgura_libre"].iloc[0]
    ffD = tabla[tabla["ID"] == "D"]["Holgura_libre"].iloc[0]
    assert ffE == 6 and ffD == 0, (ffE, ffD)
    print("test_cpm OK  dur=%s ruta=%s" % (dur, ruta))


def test_ciclo_detectado():
    df = caso_clasico()
    df.loc[df["ID"] == "A", "Predecesoras"] = "F"  # crea ciclo
    errores = validation.validar(df)
    assert any("circular" in e.lower() for e in errores), errores
    print("test_ciclo_detectado OK")


def test_crashing_lp():
    dfc = pd.DataFrame([
        {"ID": "A", "Actividad": "A", "Predecesoras": "",  "Duracion_normal": 4, "Duracion_minima": 2, "Costo_normal": 100, "Costo_acelerado": 160},
        {"ID": "B", "Actividad": "B", "Predecesoras": "A", "Duracion_normal": 6, "Duracion_minima": 3, "Costo_normal": 200, "Costo_acelerado": 350},
        {"ID": "C", "Actividad": "C", "Predecesoras": "B", "Duracion_normal": 3, "Duracion_minima": 2, "Costo_normal": 90,  "Costo_acelerado": 130},
    ])
    # Duración normal = 4+6+3 = 13. Objetivo 10 -> reducir 3 unidades.
    res = crashing.crash_lp(dfc, duracion_objetivo=10)
    assert res["estado"] == "optimo", res
    assert abs(res["duracion_lograda"] - 10) < 1e-4, res
    assert res["costo_incremental"] > 0
    print("test_crashing_lp OK  costo_incremental=%.2f dur=%.1f" %
          (res["costo_incremental"], res["duracion_lograda"]))


def test_montecarlo():
    df = caso_clasico()
    res = montecarlo.simular(df, n_iter=5000, dist="triangular", objetivo=14, semilla=1)
    # Con datos deterministas (O=M=P) la duración debe ser exactamente 14
    assert abs(res["media"] - 14) < 1e-6, res["media"]
    assert res["prob_cumplimiento"] >= 0.99, res["prob_cumplimiento"]
    print("test_montecarlo OK  media=%.3f P90=%.3f prob=%.2f" %
          (res["media"], res["P90"], res["prob_cumplimiento"]))


def test_montecarlo_variable():
    df = caso_clasico()
    # Introducir variabilidad en la ruta crítica
    df.loc[df["ID"] == "D", ["Optimista", "Mas_probable", "Pesimista", "Duracion_CPM"]] = [3, 5, 10, 0]
    res = montecarlo.simular(df, n_iter=8000, dist="beta", objetivo=15, semilla=3)
    assert res["P50"] <= res["P80"] <= res["P90"], res
    assert 0 <= res["prob_cumplimiento"] <= 1
    print("test_montecarlo_variable OK  P50=%.2f P80=%.2f P90=%.2f" %
          (res["P50"], res["P80"], res["P90"]))


def test_plantillas_y_kpis():
    for tipo in ("subterranea", "superficial"):
        dfp = mining.plantilla_df(tipo)
        tabla, ruta, dur, G = cpm.compute_cpm(dfp)
        assert dur > 0 and len(ruta) >= 2, (tipo, dur, ruta)
    k = mining.kpis_superficial(bcm=5000, toneladas=13500, horas=10, camiones=4,
                                distancia_km=3.5, velocidad=25, tiempo_ciclo_min=18,
                                disponibilidad=0.85, utilizacion=0.8)
    assert k["t/h"] == 1350.0, k
    print("test_plantillas_y_kpis OK  KPIs=%s" % k)


def test_simpy_ciclo():
    r = mining.simular_ciclo_acarreo(n_camiones=5, capacidad_t=40, t_carga=4,
                                     t_viaje_ida=8, t_descarga=2, t_viaje_vuelta=6,
                                     n_palas=2, horas_turno=10)
    assert r["ciclos_totales"] > 0 and r["toneladas_turno"] > 0, r
    print("test_simpy_ciclo OK  ciclos=%s t=%s" % (r["ciclos_totales"], r["toneladas_turno"]))


if __name__ == "__main__":
    test_pert()
    test_cpm()
    test_ciclo_detectado()
    test_crashing_lp()
    test_montecarlo()
    test_montecarlo_variable()
    test_plantillas_y_kpis()
    test_simpy_ciclo()
    print("\n=== TODAS LAS PRUEBAS PASARON ===")
