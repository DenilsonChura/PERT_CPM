"""
Exportación de resultados a Excel (.xlsx), CSV y PDF.

Excel: un libro con múltiples hojas (PERT, CPM, Ruta crítica, etc.).
CSV: una tabla por archivo (se entrega el bytes de un DataFrame).
PDF: reporte ejecutivo con reportlab (KPIs, tablas y resumen del proyecto).
"""
from __future__ import annotations

import io
from datetime import datetime
from typing import Dict, List

import pandas as pd


# ---------------------------------------------------------------------------
# Excel
# ---------------------------------------------------------------------------
def a_excel(hojas: Dict[str, pd.DataFrame]) -> bytes:
    """Empaqueta varias tablas en un único libro de Excel."""
    buffer = io.BytesIO()
    with pd.ExcelWriter(buffer, engine="openpyxl") as writer:
        for nombre, df in hojas.items():
            hoja = (nombre or "Hoja")[:31]  # límite de Excel
            (df if isinstance(df, pd.DataFrame) else pd.DataFrame(df)).to_excel(
                writer, sheet_name=hoja, index=False
            )
    return buffer.getvalue()


# ---------------------------------------------------------------------------
# CSV
# ---------------------------------------------------------------------------
def a_csv(df: pd.DataFrame) -> bytes:
    return df.to_csv(index=False).encode("utf-8-sig")


# ---------------------------------------------------------------------------
# PDF (reporte ejecutivo)
# ---------------------------------------------------------------------------
def reporte_pdf(config: dict, resumen: Dict[str, str],
                tabla_cpm: pd.DataFrame, ruta_critica: List[str],
                kpis: Dict[str, str] | None = None) -> bytes:
    """Genera un reporte PDF ejecutivo con reportlab."""
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import cm
    from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table,
                                    TableStyle)

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, topMargin=1.5 * cm,
                            bottomMargin=1.5 * cm, leftMargin=1.5 * cm,
                            rightMargin=1.5 * cm)
    estilos = getSampleStyleSheet()
    titulo = ParagraphStyle("Titulo", parent=estilos["Title"], fontSize=18,
                            textColor=colors.HexColor("#1d3557"))
    h2 = ParagraphStyle("H2", parent=estilos["Heading2"],
                        textColor=colors.HexColor("#457b9d"))
    normal = estilos["Normal"]

    elems = []
    elems.append(Paragraph("Reporte Ejecutivo — Planificación Minera PERT-CPM", titulo))
    elems.append(Spacer(1, 0.3 * cm))
    elems.append(Paragraph(
        f"Proyecto: <b>{config.get('nombre', 'Sin nombre')}</b> &nbsp;|&nbsp; "
        f"Operación: <b>{config.get('tipo', '-')}</b> &nbsp;|&nbsp; "
        f"Generado: {datetime.now().strftime('%d/%m/%Y %H:%M')}", normal))
    elems.append(Spacer(1, 0.4 * cm))

    # Resumen
    elems.append(Paragraph("Resumen del proyecto", h2))
    datos_resumen = [[k, v] for k, v in resumen.items()]
    t = Table([["Indicador", "Valor"]] + datos_resumen, colWidths=[8 * cm, 8 * cm])
    t.setStyle(_estilo_tabla())
    elems.append(t)
    elems.append(Spacer(1, 0.4 * cm))

    # KPIs operativos
    if kpis:
        elems.append(Paragraph("Indicadores operativos (KPIs)", h2))
        datos_kpi = [[k, v] for k, v in kpis.items()]
        tk = Table([["KPI", "Valor"]] + datos_kpi, colWidths=[8 * cm, 8 * cm])
        tk.setStyle(_estilo_tabla())
        elems.append(tk)
        elems.append(Spacer(1, 0.4 * cm))

    # Ruta crítica
    elems.append(Paragraph("Ruta crítica", h2))
    elems.append(Paragraph(" → ".join(ruta_critica) if ruta_critica else "N/D", normal))
    elems.append(Spacer(1, 0.4 * cm))

    # Tabla CPM (columnas clave)
    elems.append(Paragraph("Análisis CPM por actividad", h2))
    cols = ["ID", "Actividad", "Duracion", "Inicio_temprano", "Fin_temprano",
            "Holgura_total", "Critica"]
    cols = [c for c in cols if c in tabla_cpm.columns]
    encabezado = ["ID", "Actividad", "Dur", "ES", "EF", "H.Total", "Crítica"]
    filas = [encabezado]
    for _, r in tabla_cpm.iterrows():
        filas.append([str(r[c]) if c != "Critica" else ("Sí" if r[c] else "No")
                      for c in cols])
    tc = Table(filas, repeatRows=1)
    tc.setStyle(_estilo_tabla(compacto=True))
    # Resaltar críticas
    for i, (_, r) in enumerate(tabla_cpm.iterrows(), start=1):
        if r.get("Critica"):
            tc.setStyle(TableStyle([("BACKGROUND", (0, i), (-1, i),
                                     colors.HexColor("#ffd6d6"))]))
    elems.append(tc)

    doc.build(elems)
    return buffer.getvalue()


def _estilo_tabla(compacto: bool = False):
    from reportlab.lib import colors
    from reportlab.platypus import TableStyle
    fs = 7 if compacto else 9
    return TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1d3557")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), fs),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#adb5bd")),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f1f3f5")]),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ])
