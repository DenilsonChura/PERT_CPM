"""
Validaciones de integridad del modelo de actividades.

Detecta dependencias circulares, predecesoras inexistentes, IDs duplicados y
valores PERT inconsistentes (O <= M <= P).
"""
from __future__ import annotations

from typing import List

import networkx as nx
import pandas as pd

from core import models
from core.models import COL_ID, COL_O, COL_M, COL_P


def validar(df: pd.DataFrame) -> List[str]:
    """Devuelve una lista de mensajes de error/advertencia (vacía si todo ok)."""
    errores: List[str] = []
    dfn = models.normalizar_df(df)

    if dfn.empty:
        return ["No hay actividades registradas."]

    # IDs duplicados (antes de normalizar quita duplicados, revisamos original)
    ids_orig = df[COL_ID].astype(str).str.strip() if COL_ID in df.columns else pd.Series([], dtype=str)
    dups = ids_orig[ids_orig.duplicated() & (ids_orig != "")].unique()
    if len(dups):
        errores.append(f"IDs duplicados: {', '.join(map(str, dups))}")

    ids = set(dfn[COL_ID])

    # Predecesoras inexistentes
    for _, r in dfn.iterrows():
        faltantes = [p for p in r["_preds"] if p not in ids]
        if faltantes:
            errores.append(f"Actividad {r[COL_ID]}: predecesora(s) inexistente(s) {', '.join(faltantes)}")

    # Auto-referencia
    for _, r in dfn.iterrows():
        if r[COL_ID] in r["_preds"]:
            errores.append(f"Actividad {r[COL_ID]} se referencia a sí misma.")

    # Consistencia PERT
    for _, r in dfn.iterrows():
        o, m, p = r[COL_O], r[COL_M], r[COL_P]
        if not (o <= m <= p):
            errores.append(f"Actividad {r[COL_ID]}: se esperaba O ≤ M ≤ P (O={o}, M={m}, P={p}).")

    # Ciclos
    G = nx.DiGraph()
    G.add_nodes_from(ids)
    for _, r in dfn.iterrows():
        for p in r["_preds"]:
            if p in ids:
                G.add_edge(p, r[COL_ID])
    if not nx.is_directed_acyclic_graph(G):
        try:
            ciclo = nx.find_cycle(G)
            ruta = " -> ".join([u for u, _v in ciclo] + [ciclo[-1][1]])
            errores.append(f"Dependencia circular detectada: {ruta}")
        except nx.NetworkXNoCycle:
            errores.append("Dependencia circular detectada.")

    return errores


def es_valido(df: pd.DataFrame) -> bool:
    return len(validar(df)) == 0
