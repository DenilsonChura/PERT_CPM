"""
Gestión del estado de sesión de Streamlit.

Centraliza inicialización y acceso a los datos del proyecto para evitar
dispersión de claves ``st.session_state`` por toda la aplicación.
"""
from __future__ import annotations

from datetime import date, timedelta

import pandas as pd
import streamlit as st

from core import mining, models


def init_state():
    """Inicializa el estado de sesión la primera vez."""
    ss = st.session_state
    if "config" not in ss:
        ss.config = {
            "nombre": "Proyecto Minero Demo",
            "tipo": "Subterránea",
            "horizonte": "Semanal",
            "turnos": 2,
            "horas_turno": 8.0,
            "fecha_inicio": date.today(),
            "fecha_objetivo": date.today() + timedelta(days=30),
        }
    if "actividades" not in ss:
        # Cargar plantilla subterránea por defecto
        ss.actividades = mining.plantilla_df("subterranea")
    if "avance" not in ss:
        ss.avance = {}


def get_actividades() -> pd.DataFrame:
    return st.session_state.actividades


def set_actividades(df: pd.DataFrame):
    st.session_state.actividades = df


def get_config() -> dict:
    return st.session_state.config
