"""Dashboard ejecutivo: KPIs consolidados y visualizaciones."""
from __future__ import annotations

from datetime import datetime

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from core import cpm, pert
from io_utils import state
from . import components as C


def dashboard():
    C.cabecera("📈 Dashboard ejecutivo",
               "Vista consolidada del proyecto para centros de control")
    if not C.guard_actividades():
        return

    df = state.get_actividades()
    cfg = state.get_config()
    tabla, ruta, dur, G = cpm.compute_cpm(df)
    tpert = pert.calcular_pert(df)
    est = pert.estadisticos_ruta(tpert, ruta)

    # Índice de cumplimiento vs fecha objetivo (en días de calendario)
    dias_objetivo = (cfg["fecha_objetivo"] - cfg["fecha_inicio"]).days
    indice = (dias_objetivo / dur) if dur > 0 else 0
    costo_total = float(df["Costo"].sum()) if "Costo" in df.columns else 0.0
    avance = st.session_state.get("avance", {})
    avance_prom = (sum(avance.values()) / len(avance)) if avance else 0
    prod_estimada = float(pd.to_numeric(df.get("Recursos"), errors="coerce").sum() or 0)

    # ---- Fila de tarjetas KPI ----
    k = st.columns(4)
    C.kpi_card(k[0], "Duración del proyecto", f"{dur:g}", cfg["horizonte"], tipo="ok")
    C.kpi_card(k[1], "N.º de actividades", len(tabla))
    C.kpi_card(k[2], "Actividades críticas", int(tabla["Critica"].sum()), tipo="crit")
    C.kpi_card(k[3], "Índice de cumplimiento",
               f"{indice:.2f}", "≥1 dentro de plazo",
               tipo="ok" if indice >= 1 else "warn")

    k2 = st.columns(4)
    C.kpi_card(k2[0], "Costo acumulado", f"{costo_total:,.0f}")
    C.kpi_card(k2[1], "Avance promedio", f"{avance_prom:.0f}%",
               tipo="ok" if avance_prom >= 50 else "warn")
    C.kpi_card(k2[2], "Duración esperada (PERT)", f"{est['media']:g}")
    C.kpi_card(k2[3], "Desviación σ", f"{est['desviacion']:g}")

    st.divider()

    # ---- Gráficos ----
    g1, g2 = st.columns(2)
    with g1:
        st.markdown("**Duración por actividad (barras)**")
        fig = px.bar(tabla, x="ID", y="Duracion",
                     color="Critica", color_discrete_map={True: "#e63946", False: "#457b9d"},
                     labels={"Duracion": "Duración"})
        fig.update_layout(template="plotly_dark", height=340, showlegend=False)
        st.plotly_chart(fig, use_container_width=True)

    with g2:
        st.markdown("**Distribución críticas vs no críticas (circular)**")
        n_crit = int(tabla["Critica"].sum())
        fig = go.Figure(go.Pie(labels=["Críticas", "No críticas"],
                               values=[n_crit, len(tabla) - n_crit], hole=0.5,
                               marker_colors=["#e63946", "#457b9d"]))
        fig.update_layout(template="plotly_dark", height=340)
        st.plotly_chart(fig, use_container_width=True)

    g3, g4 = st.columns(2)
    with g3:
        st.markdown("**Costo acumulado por secuencia (línea)**")
        seq = tabla.sort_values("Inicio_temprano").copy()
        costos = df.set_index("ID").reindex(seq["ID"])["Costo"].fillna(0).values \
            if "Costo" in df.columns else [0] * len(seq)
        seq["Costo_acum"] = pd.Series(costos).cumsum().values
        fig = px.line(seq, x="ID", y="Costo_acum", markers=True)
        fig.update_traces(line_color="#2a9d8f")
        fig.update_layout(template="plotly_dark", height=340)
        st.plotly_chart(fig, use_container_width=True)

    with g4:
        st.markdown("**Índice de cumplimiento (gauge)**")
        fig = go.Figure(go.Indicator(
            mode="gauge+number", value=indice * 100,
            number={"suffix": "%"},
            gauge={
                "axis": {"range": [0, 150]},
                "bar": {"color": "#2a9d8f" if indice >= 1 else "#e63946"},
                "steps": [
                    {"range": [0, 80], "color": "#5c1a1a"},
                    {"range": [80, 100], "color": "#7f5539"},
                    {"range": [100, 150], "color": "#1b4332"},
                ],
                "threshold": {"line": {"color": "white", "width": 3},
                              "thickness": 0.75, "value": 100},
            },
            title={"text": "Plazo objetivo / Duración"},
        ))
        fig.update_layout(template="plotly_dark", height=340)
        st.plotly_chart(fig, use_container_width=True)

    st.divider()
    st.markdown("**Resumen ejecutivo**")
    resumen = pd.DataFrame({
        "Indicador": ["Proyecto", "Operación", "Horizonte", "Ruta crítica",
                      "Duración (CPM)", "Duración esperada (PERT)", "Fecha objetivo"],
        "Valor": [cfg["nombre"], cfg["tipo"], cfg["horizonte"], " → ".join(ruta),
                  f"{dur:g}", f"{est['media']:g}", str(cfg["fecha_objetivo"])],
    })
    st.dataframe(resumen, use_container_width=True, hide_index=True)
