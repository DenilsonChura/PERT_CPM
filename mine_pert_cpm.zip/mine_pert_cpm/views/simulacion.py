"""Vista de Simulación Monte Carlo de la duración del proyecto."""
from __future__ import annotations

from datetime import datetime

import numpy as np
import plotly.graph_objects as go
import streamlit as st

from core import cpm, montecarlo
from io_utils import state
from . import components as C


def simulacion():
    C.cabecera("🎲 Simulación Monte Carlo",
               "Riesgo del cronograma a partir de los tiempos PERT")
    if not C.guard_actividades():
        return

    df = state.get_actividades()
    _, ruta, dur_det, _ = cpm.compute_cpm(df)
    cfg = state.get_config()

    c1, c2, c3 = st.columns(3)
    n_iter = c1.select_slider("Iteraciones", [1000, 5000, 10000, 20000, 50000], value=10000)
    dist = c2.selectbox("Distribución", ["triangular", "beta"],
                        format_func=lambda x: "Triangular" if x == "triangular" else "Beta-PERT")
    objetivo = c3.number_input("Duración objetivo", 0.0, 1e6, float(round(dur_det, 1)), step=1.0)

    if st.button("▶️ Ejecutar simulación", type="primary"):
        with st.spinner("Simulando..."):
            res = montecarlo.simular(df, n_iter=n_iter, dist=dist, objetivo=objetivo)
        st.session_state["mc_res"] = res

    res = st.session_state.get("mc_res")
    if not res:
        st.info("Configure los parámetros y ejecute la simulación.")
        return

    k = st.columns(4)
    C.kpi_card(k[0], "Media", f"{res['media']:.1f}", f"det.: {dur_det:g}", tipo="ok")
    C.kpi_card(k[1], "P80", f"{res['P80']:.1f}", "80% de confianza", tipo="warn")
    C.kpi_card(k[2], "P90", f"{res['P90']:.1f}", "90% de confianza", tipo="crit")
    prob = res["prob_cumplimiento"]
    C.kpi_card(k[3], "Prob. cumplir objetivo",
               f"{prob*100:.1f}%" if prob is not None else "—",
               tipo="ok" if (prob or 0) >= 0.8 else "warn")

    k2 = st.columns(3)
    C.kpi_card(k2[0], "P50 (mediana)", f"{res['P50']:.1f}")
    C.kpi_card(k2[1], "Mínimo", f"{res['min']:.1f}")
    C.kpi_card(k2[2], "Máximo", f"{res['max']:.1f}")

    dur = res["duraciones"]
    g1, g2 = st.columns(2)
    with g1:
        fig = go.Figure(go.Histogram(x=dur, nbinsx=50, marker_color="#457b9d"))
        for pct, key, col in [(50, "P50", "#f4a261"), (80, "P80", "#e76f51"),
                              (90, "P90", "#e63946")]:
            fig.add_vline(x=res[key], line_dash="dash", line_color=col,
                          annotation_text=f"{key}")
        if res["objetivo"]:
            fig.add_vline(x=res["objetivo"], line_color="#2a9d8f",
                          annotation_text="Objetivo")
        fig.update_layout(template="plotly_dark", height=400,
                          title=f"Distribución de la duración ({res['n_iter']:,} iter.)",
                          xaxis_title="Duración", yaxis_title="Frecuencia")
        st.plotly_chart(fig, use_container_width=True)

    with g2:
        orden = np.sort(dur)
        acum = np.arange(1, len(orden) + 1) / len(orden) * 100
        figc = go.Figure(go.Scatter(x=orden, y=acum, line=dict(color="#2a9d8f", width=3)))
        for pct, key, col in [(50, "P50", "#f4a261"), (80, "P80", "#e76f51"),
                              (90, "P90", "#e63946")]:
            figc.add_vline(x=res[key], line_dash="dot", line_color=col,
                           annotation_text=key)
        if res["objetivo"]:
            figc.add_vline(x=res["objetivo"], line_color="white",
                           annotation_text="Objetivo")
        figc.update_layout(template="plotly_dark", height=400,
                           title="Curva acumulada (S-curve)",
                           xaxis_title="Duración", yaxis_title="Probabilidad acumulada (%)")
        st.plotly_chart(figc, use_container_width=True)

    interpretacion = (
        f"Existe un **{prob*100:.1f}%** de probabilidad de completar el proyecto "
        f"en **{objetivo:g}** unidades o menos. "
        if prob is not None else ""
    )
    st.info(interpretacion +
            f"Para una planificación conservadora considere el **P80 = {res['P80']:.1f}** "
            f"o el **P90 = {res['P90']:.1f}** como fecha comprometida.")
