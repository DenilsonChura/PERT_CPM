"""Vistas generales: Inicio, Configuración del proyecto y Exportar resultados."""
from __future__ import annotations

from datetime import datetime

import pandas as pd
import streamlit as st

from core import cpm, mining, pert
from io_utils import exporters, state, validation
from . import components as C


# ---------------------------------------------------------------------------
# INICIO
# ---------------------------------------------------------------------------
def inicio():
    C.cabecera("⛏️ MinePlanner PERT-CPM",
               "Planificación, programación y optimización de operaciones mineras")

    st.markdown(
        """
Bienvenido a **MinePlanner**, una plataforma profesional para la planificación
de operaciones de **minería subterránea** y **minería superficial (cielo abierto)**
mediante las metodologías **PERT** y **CPM**.

**¿Qué puede hacer con esta herramienta?**
- Modelar actividades y relaciones de precedencia.
- Calcular tiempos esperados (PERT) y la ruta crítica (CPM).
- Analizar holguras y optimizar la duración vía *crashing*.
- Evaluar el riesgo del cronograma con **simulación Monte Carlo**.
- Usar plantillas mineras y calcular KPIs operativos.
- Exportar reportes ejecutivos en **Excel, CSV y PDF**.
        """
    )

    df = state.get_actividades()
    cfg = state.get_config()

    c1, c2, c3, c4 = st.columns(4)
    C.kpi_card(c1, "Proyecto", cfg["nombre"][:18], cfg["tipo"])
    C.kpi_card(c2, "Actividades", len(df))
    try:
        _, ruta, dur, _ = cpm.compute_cpm(df)
        C.kpi_card(c3, "Duración estimada", f"{dur:g}", "unidades de tiempo", tipo="ok")
        C.kpi_card(c4, "Actividades críticas", len(ruta), " → ".join(ruta), tipo="crit")
    except Exception:
        C.kpi_card(c3, "Duración estimada", "—")
        C.kpi_card(c4, "Actividades críticas", "—")

    st.divider()
    st.subheader("Comenzar rápido")
    col1, col2 = st.columns(2)
    if col1.button("🏗️ Cargar plantilla — Subterránea", use_container_width=True):
        state.set_actividades(mining.plantilla_df("subterranea"))
        st.session_state.config["tipo"] = "Subterránea"
        st.success("Plantilla subterránea cargada.")
        st.rerun()
    if col2.button("🚜 Cargar plantilla — Superficial", use_container_width=True):
        state.set_actividades(mining.plantilla_df("superficial"))
        st.session_state.config["tipo"] = "Superficial"
        st.success("Plantilla superficial cargada.")
        st.rerun()


# ---------------------------------------------------------------------------
# CONFIGURACIÓN
# ---------------------------------------------------------------------------
def configuracion():
    C.cabecera("⚙️ Configuración del proyecto")
    cfg = state.get_config()

    c1, c2 = st.columns(2)
    cfg["nombre"] = c1.text_input("Nombre del proyecto", cfg["nombre"])
    cfg["tipo"] = c2.selectbox("Tipo de operación", ["Subterránea", "Superficial"],
                               index=0 if cfg["tipo"] == "Subterránea" else 1)

    c3, c4 = st.columns(2)
    cfg["horizonte"] = c3.selectbox(
        "Horizonte de planificación", ["Diario", "Semanal", "Mensual", "Anual"],
        index=["Diario", "Semanal", "Mensual", "Anual"].index(cfg["horizonte"]),
    )
    cfg["turnos"] = c4.number_input("Número de turnos", min_value=1, max_value=4,
                                    value=int(cfg["turnos"]))

    c5, c6 = st.columns(2)
    cfg["horas_turno"] = c5.number_input("Horas por turno", min_value=1.0, max_value=24.0,
                                         value=float(cfg["horas_turno"]), step=0.5)
    cfg["fecha_inicio"] = c5.date_input("Fecha de inicio", cfg["fecha_inicio"])
    cfg["fecha_objetivo"] = c6.date_input("Fecha objetivo", cfg["fecha_objetivo"])

    horas_dia = cfg["turnos"] * cfg["horas_turno"]
    c6.metric("Horas productivas por día", f"{horas_dia:g} h")

    st.success("Configuración guardada automáticamente en la sesión.")


# ---------------------------------------------------------------------------
# EXPORTAR
# ---------------------------------------------------------------------------
def exportar():
    C.cabecera("📤 Exportar resultados",
               "Descargue los análisis en Excel, CSV o PDF")
    if not C.guard_actividades():
        return

    df = state.get_actividades()
    cfg = state.get_config()
    tabla_cpm, ruta, dur, G = cpm.compute_cpm(df)
    tabla_pert = pert.calcular_pert(df)
    est = pert.estadisticos_ruta(tabla_pert, ruta)
    tabla_ruta = tabla_cpm[tabla_cpm["Critica"]]

    resumen = {
        "Nombre del proyecto": cfg["nombre"],
        "Tipo de operación": cfg["tipo"],
        "Número de actividades": str(len(df)),
        "Duración del proyecto (CPM)": f"{dur:g}",
        "Duración esperada (PERT)": f"{est['media']:g}",
        "Desviación estándar (PERT)": f"{est['desviacion']:g}",
        "Actividades críticas": str(int(tabla_cpm['Critica'].sum())),
        "Ruta crítica": " → ".join(ruta),
    }

    st.subheader("Resumen que se exportará")
    st.table(pd.DataFrame(resumen.items(), columns=["Indicador", "Valor"]))

    hojas = {
        "PERT": tabla_pert,
        "CPM": tabla_cpm,
        "Ruta_critica": tabla_ruta,
        "Actividades": df,
        "Resumen": pd.DataFrame(resumen.items(), columns=["Indicador", "Valor"]),
    }

    c1, c2, c3 = st.columns(3)
    c1.download_button(
        "⬇️ Excel (.xlsx)", data=exporters.a_excel(hojas),
        file_name=f"{cfg['nombre']}_reporte.xlsx",
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        use_container_width=True,
    )

    tabla_sel = c2.selectbox("Tabla para CSV", list(hojas.keys()))
    c2.download_button(
        "⬇️ CSV", data=exporters.a_csv(hojas[tabla_sel]),
        file_name=f"{cfg['nombre']}_{tabla_sel}.csv", mime="text/csv",
        use_container_width=True,
    )

    try:
        pdf = exporters.reporte_pdf(cfg, resumen, tabla_cpm, ruta)
        c3.download_button(
            "⬇️ PDF ejecutivo", data=pdf,
            file_name=f"{cfg['nombre']}_ejecutivo.pdf", mime="application/pdf",
            use_container_width=True,
        )
    except Exception as e:  # pragma: no cover
        c3.error(f"PDF no disponible: {e}")
