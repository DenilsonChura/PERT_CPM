"""Vista de Registro de actividades (tabla editable + import Excel)."""
from __future__ import annotations

import pandas as pd
import streamlit as st

from core import mining, models
from core.models import (COL_ID, COL_NOMBRE, COL_PRED, COL_O, COL_M, COL_P,
                         COL_DUR, COL_COSTO, COL_REC, COLUMNAS, ETIQUETAS)
from io_utils import state, validation
from . import components as C


def registro():
    C.cabecera("📋 Registro de actividades",
               "Agregue, edite o elimine actividades y sus predecesoras")

    # Barra de acciones
    c1, c2, c3, c4 = st.columns([1.2, 1.2, 1.2, 1.4])
    if c1.button("➕ Fila vacía", use_container_width=True):
        df = state.get_actividades().copy()
        nuevo_id = _siguiente_id(df)
        fila = {c: (nuevo_id if c == COL_ID else (0 if c in (COL_O, COL_M, COL_P, COL_DUR, COL_COSTO) else ""))
                for c in COLUMNAS}
        state.set_actividades(pd.concat([df, pd.DataFrame([fila])], ignore_index=True))
        st.rerun()
    if c2.button("🏗️ Plantilla subterránea", use_container_width=True):
        state.set_actividades(mining.plantilla_df("subterranea"))
        st.rerun()
    if c3.button("🚜 Plantilla superficial", use_container_width=True):
        state.set_actividades(mining.plantilla_df("superficial"))
        st.rerun()
    if c4.button("🗑️ Vaciar tabla", use_container_width=True):
        state.set_actividades(models.df_vacio())
        st.rerun()

    st.markdown("##### Importar desde Excel")
    archivo = st.file_uploader("Archivo .xlsx con las columnas estándar",
                               type=["xlsx"], label_visibility="collapsed")
    if archivo is not None:
        try:
            imp = pd.read_excel(archivo)
            imp = _mapear_columnas(imp)
            state.set_actividades(imp)
            st.success(f"Importadas {len(imp)} actividades.")
            st.rerun()
        except Exception as e:
            st.error(f"No se pudo importar: {e}")

    st.divider()

    # Editor de datos
    df = state.get_actividades().copy()
    for c in COLUMNAS:
        if c not in df.columns:
            df[c] = 0 if c in (COL_O, COL_M, COL_P, COL_DUR, COL_COSTO) else ""

    config_cols = {
        COL_ID: st.column_config.TextColumn("ID", required=True, width="small"),
        COL_NOMBRE: st.column_config.TextColumn("Actividad", width="large"),
        COL_PRED: st.column_config.TextColumn("Predecesoras", help="IDs separados por coma, p. ej. A,B"),
        COL_O: st.column_config.NumberColumn("Optimista (O)", min_value=0.0, format="%.2f"),
        COL_M: st.column_config.NumberColumn("Más probable (M)", min_value=0.0, format="%.2f"),
        COL_P: st.column_config.NumberColumn("Pesimista (P)", min_value=0.0, format="%.2f"),
        COL_DUR: st.column_config.NumberColumn("Duración CPM", min_value=0.0, format="%.2f",
                                               help="0 = usar tiempo esperado PERT"),
        COL_COSTO: st.column_config.NumberColumn("Costo", min_value=0.0, format="%.2f"),
        COL_REC: st.column_config.TextColumn("Recursos"),
    }

    editado = st.data_editor(
        df[COLUMNAS], num_rows="dynamic", use_container_width=True,
        column_config=config_cols, key="editor_actividades", height=420,
    )
    state.set_actividades(editado)

    # Validación en vivo
    errores = validation.validar(editado)
    if errores:
        st.error("⚠️ Problemas detectados:")
        for e in errores:
            st.markdown(f"- {e}")
    else:
        st.success(f"✅ Modelo válido — {len(editado)} actividades sin dependencias circulares.")

    with st.expander("📖 Ayuda de columnas"):
        st.markdown(
            "- **ID**: identificador único (A, B, 10, T-01...).\n"
            "- **Predecesoras**: IDs que deben terminar antes (relación fin-inicio).\n"
            "- **O / M / P**: estimaciones optimista, más probable y pesimista para PERT.\n"
            "- **Duración CPM**: si es 0, el sistema usa el tiempo esperado PERT.\n"
            "- **Costo / Recursos**: para el diagrama de Gantt y el análisis económico."
        )


def _siguiente_id(df: pd.DataFrame) -> str:
    existentes = set(df[COL_ID].astype(str)) if COL_ID in df.columns else set()
    import string
    for letra in string.ascii_uppercase:
        if letra not in existentes:
            return letra
    i = 1
    while f"A{i}" in existentes:
        i += 1
    return f"A{i}"


def _mapear_columnas(df: pd.DataFrame) -> pd.DataFrame:
    """Intenta mapear columnas importadas a los nombres estándar."""
    alias = {
        "id": COL_ID, "actividad": COL_NOMBRE, "nombre": COL_NOMBRE,
        "predecesoras": COL_PRED, "predecesora": COL_PRED, "pred": COL_PRED,
        "optimista": COL_O, "o": COL_O,
        "mas probable": COL_M, "más probable": COL_M, "mas_probable": COL_M, "m": COL_M,
        "pesimista": COL_P, "p": COL_P,
        "duracion_cpm": COL_DUR, "duración cpm": COL_DUR, "duracion": COL_DUR,
        "costo": COL_COSTO, "recursos": COL_REC,
    }
    ren = {}
    for c in df.columns:
        key = str(c).strip().lower()
        if key in alias:
            ren[c] = alias[key]
    df = df.rename(columns=ren)
    for c in COLUMNAS:
        if c not in df.columns:
            df[c] = 0 if c in (COL_O, COL_M, COL_P, COL_DUR, COL_COSTO) else ""
    return df[COLUMNAS]
