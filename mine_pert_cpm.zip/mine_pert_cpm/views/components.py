"""Componentes de interfaz reutilizables (tarjetas KPI, estilos, cabeceras)."""
from __future__ import annotations

from typing import List

import pandas as pd
import streamlit as st

from core import cpm
from io_utils import validation, state


CSS = """
<style>
  .kpi-card {
      background: linear-gradient(135deg, #1d3557 0%, #2a4d6e 100%);
      border-radius: 14px; padding: 16px 18px; color: #fff;
      box-shadow: 0 4px 14px rgba(0,0,0,0.25); border: 1px solid #ffffff14;
  }
  .kpi-card .label { font-size: 0.78rem; opacity: 0.8; letter-spacing: .4px;
      text-transform: uppercase; }
  .kpi-card .value { font-size: 1.7rem; font-weight: 700; margin-top: 4px; }
  .kpi-card .delta { font-size: 0.8rem; opacity: 0.85; margin-top: 2px; }
  .kpi-crit { background: linear-gradient(135deg, #9d0208 0%, #d00000 100%); }
  .kpi-ok   { background: linear-gradient(135deg, #1b4332 0%, #2d6a4f 100%); }
  .kpi-warn { background: linear-gradient(135deg, #7f5539 0%, #b08968 100%); }
  .section-title { border-left: 5px solid #e63946; padding-left: 12px; }
</style>
"""


def inject_css():
    st.markdown(CSS, unsafe_allow_html=True)


def kpi_card(col, label: str, value, delta: str = "", tipo: str = ""):
    """Renderiza una tarjeta KPI en la columna dada."""
    clase = {"crit": "kpi-crit", "ok": "kpi-ok", "warn": "kpi-warn"}.get(tipo, "")
    col.markdown(
        f"""<div class="kpi-card {clase}">
              <div class="label">{label}</div>
              <div class="value">{value}</div>
              <div class="delta">{delta}</div>
            </div>""",
        unsafe_allow_html=True,
    )


def cabecera(titulo: str, subtitulo: str = ""):
    st.markdown(f"<h2 class='section-title'>{titulo}</h2>", unsafe_allow_html=True)
    if subtitulo:
        st.caption(subtitulo)


def guard_actividades() -> bool:
    """Verifica que existan actividades válidas; muestra errores si los hay.

    Devuelve True si es seguro continuar con el análisis.
    """
    df = state.get_actividades()
    if df is None or df.empty:
        st.warning("No hay actividades registradas. Vaya a **Registro de actividades**.")
        return False
    errores = validation.validar(df)
    if errores:
        st.error("Se encontraron problemas en el modelo de actividades:")
        for e in errores:
            st.markdown(f"- {e}")
        return False
    return True


def resultado_cpm():
    """Ejecuta y cachea el CPM sobre las actividades actuales."""
    df = state.get_actividades()
    return cpm.compute_cpm(df)
