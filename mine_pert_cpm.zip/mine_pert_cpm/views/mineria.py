"""Vistas de minería subterránea y superficial: plantillas, KPIs y SimPy."""
from __future__ import annotations

import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from core import mining
from io_utils import state
from . import components as C


# ---------------------------------------------------------------------------
# SUBTERRÁNEA
# ---------------------------------------------------------------------------
def subterranea():
    C.cabecera("🏗️ Minería subterránea",
               "Plantillas de labores, variables e indicadores operativos")

    st.subheader("Plantillas de labores")
    labores = ["Desarrollo horizontal", "Rampas", "Chimeneas", "Producción",
               "Sostenimiento", "Preparación de tajos"]
    st.write("Ciclo típico: perforación → carguío → voladura → ventilación → "
             "desatado → sostenimiento → limpieza → transporte.")
    cols = st.columns(3)
    for i, l in enumerate(labores):
        cols[i % 3].markdown(f"- **{l}**")

    if st.button("📥 Cargar plantilla de actividades subterránea", type="primary"):
        state.set_actividades(mining.plantilla_df("subterranea"))
        st.session_state.config["tipo"] = "Subterránea"
        st.success("Plantilla cargada. Vaya a **Análisis CPM** para ver resultados.")

    st.divider()
    st.subheader("Variables e indicadores")
    c1, c2, c3 = st.columns(3)
    metros = c1.number_input("Metros perforados", 0.0, 100000.0, 320.0)
    dias = c1.number_input("Días del periodo", 1.0, 365.0, 30.0)
    guardias = c2.number_input("N.º de guardias", 1.0, 1000.0, 60.0)
    avance = c2.number_input("Avance por guardia (m)", 0.0, 50.0, 3.2)
    toneladas = c3.number_input("Toneladas producidas", 0.0, 1e7, 45000.0)
    equipos = c3.number_input("N.º de equipos", 1.0, 100.0, 4.0)

    c4, c5 = st.columns(2)
    disp = c4.slider("Disponibilidad mecánica", 0.0, 1.0, 0.85)
    util = c5.slider("Utilización", 0.0, 1.0, 0.75)

    k = mining.kpis_subterranea(metros, guardias, avance, disp, util,
                                toneladas, equipos, dias)
    st.subheader("KPIs")
    kc = st.columns(4)
    C.kpi_card(kc[0], "Avance", f"{k['m/dia']} m/día", tipo="ok")
    C.kpi_card(kc[1], "Producción", f"{k['t/dia']} t/día")
    C.kpi_card(kc[2], "Por guardia", f"{k['t/guardia']} t")
    C.kpi_card(kc[3], "Efectividad", f"{k['efectividad_%']}%", "Disp × Util", tipo="warn")
    st.dataframe(pd.DataFrame(k.items(), columns=["Indicador", "Valor"]),
                 use_container_width=True, hide_index=True)

    _simulador_acarreo(contexto="subterranea")


# ---------------------------------------------------------------------------
# SUPERFICIAL
# ---------------------------------------------------------------------------
def superficial():
    C.cabecera("🚜 Minería superficial (cielo abierto)",
               "Plantillas de operaciones, variables e indicadores de flota")

    st.subheader("Plantillas de operaciones")
    ops = ["Perforación de bancos", "Voladura", "Carguío", "Transporte",
           "Chancado", "Botaderos", "Stockpile"]
    cols = st.columns(4)
    for i, o in enumerate(ops):
        cols[i % 4].markdown(f"- **{o}**")

    if st.button("📥 Cargar plantilla de actividades superficial", type="primary"):
        state.set_actividades(mining.plantilla_df("superficial"))
        st.session_state.config["tipo"] = "Superficial"
        st.success("Plantilla cargada. Vaya a **Análisis CPM** para ver resultados.")

    st.divider()
    st.subheader("Variables e indicadores de flota")
    c1, c2, c3 = st.columns(3)
    bcm = c1.number_input("BCM movidos", 0.0, 1e7, 50000.0)
    toneladas = c1.number_input("Toneladas movidas", 0.0, 1e7, 135000.0)
    horas = c2.number_input("Horas operativas", 1.0, 100000.0, 100.0)
    camiones = c2.number_input("N.º de camiones", 1.0, 200.0, 6.0)
    distancia = c3.number_input("Distancia de acarreo (km)", 0.0, 100.0, 3.5)
    velocidad = c3.number_input("Velocidad promedio (km/h)", 1.0, 80.0, 25.0)

    c4, c5, c6 = st.columns(3)
    ciclo = c4.number_input("Tiempo de ciclo (min)", 1.0, 240.0, 18.0)
    disp = c5.slider("Disponibilidad de flota", 0.0, 1.0, 0.85)
    util = c6.slider("Utilización de equipos", 0.0, 1.0, 0.80)

    k = mining.kpis_superficial(bcm, toneladas, horas, camiones, distancia,
                               velocidad, ciclo, disp, util)
    st.subheader("KPIs")
    kc = st.columns(4)
    C.kpi_card(kc[0], "Movimiento", f"{k['BCM/h']} BCM/h", tipo="ok")
    C.kpi_card(kc[1], "Producción", f"{k['t/h']} t/h")
    C.kpi_card(kc[2], "Por camión", f"{k['t/camion']} t")
    C.kpi_card(kc[3], "Efectividad", f"{k['efectividad_%']}%", "Disp × Util", tipo="warn")
    st.dataframe(pd.DataFrame(k.items(), columns=["Indicador", "Valor"]),
                 use_container_width=True, hide_index=True)

    _simulador_acarreo(contexto="superficial")


# ---------------------------------------------------------------------------
# SIMULADOR SIMPY (compartido)
# ---------------------------------------------------------------------------
def _simulador_acarreo(contexto: str):
    st.divider()
    st.subheader("🔄 Simulación de ciclo de acarreo (SimPy)")
    st.caption("Simulación de eventos discretos: camiones compitiendo por palas/equipos "
               "de carguío durante un turno. Tiempos en minutos.")
    c1, c2, c3, c4 = st.columns(4)
    ncam = c1.number_input("Camiones", 1, 60, 6, key=f"sc_{contexto}_1")
    cap = c1.number_input("Capacidad (t)", 1.0, 400.0, 40.0, key=f"sc_{contexto}_2")
    tcarga = c2.number_input("T. carga", 0.5, 60.0, 4.0, key=f"sc_{contexto}_3")
    tida = c2.number_input("T. viaje ida", 0.5, 120.0, 8.0, key=f"sc_{contexto}_4")
    tdesc = c3.number_input("T. descarga", 0.5, 30.0, 2.0, key=f"sc_{contexto}_5")
    tvuelta = c3.number_input("T. viaje vuelta", 0.5, 120.0, 6.0, key=f"sc_{contexto}_6")
    npalas = c4.number_input("Palas/equipos carguío", 1, 20, 2, key=f"sc_{contexto}_7")
    horas = c4.number_input("Horas de turno", 1.0, 24.0, 10.0, key=f"sc_{contexto}_8")

    if st.button("▶️ Ejecutar simulación", key=f"run_{contexto}"):
        r = mining.simular_ciclo_acarreo(int(ncam), cap, tcarga, tida, tdesc,
                                         tvuelta, int(npalas), horas)
        kc = st.columns(4)
        C.kpi_card(kc[0], "Ciclos completados", r["ciclos_totales"], tipo="ok")
        C.kpi_card(kc[1], "Producción del turno", f"{r['toneladas_turno']:,.0f} t")
        C.kpi_card(kc[2], "Ritmo", f"{r['t/h']} t/h")
        C.kpi_card(kc[3], "Prod. flota", f"{r['productividad_flota_t/h']} t/h·camión", tipo="warn")

        fig = go.Figure(go.Bar(x=["Ciclos", "t/h", "t/camión"],
                               y=[r["ciclos_totales"], r["t/h"], r["t/camion"]],
                               marker_color=["#457b9d", "#2a9d8f", "#e63946"]))
        fig.update_layout(template="plotly_dark", height=320,
                          title="Resultados de la simulación de acarreo")
        st.plotly_chart(fig, use_container_width=True)
