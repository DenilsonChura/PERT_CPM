"""Vista de Optimización y Crashing (reducción de duración tiempo-costo)."""
from __future__ import annotations

import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from core import cpm, crashing
from core.models import COL_ID, COL_NOMBRE, COL_PRED, COL_COSTO
from io_utils import state
from . import components as C


def optimizacion():
    C.cabecera("⚡ Optimización y Crashing",
               "Reduzca la duración al menor costo posible (tiempo-costo)")
    if not C.guard_actividades():
        return

    df = state.get_actividades()
    tabla, ruta, dur, G = cpm.compute_cpm(df)

    st.info(f"Duración normal del proyecto (CPM): **{dur:g}** unidades. "
            f"Ruta crítica: **{' → '.join(ruta)}**")

    # Construir tabla de crashing a partir de las actividades
    st.subheader("1) Parámetros de aceleración por actividad")
    st.caption("Defina duración mínima y costos normal/acelerado. "
               "La duración normal se toma de la duración CPM/PERT actual.")

    base = pd.DataFrame({
        COL_ID: tabla[COL_ID],
        COL_NOMBRE: tabla[COL_NOMBRE],
        "Predecesoras": df.set_index(COL_ID).reindex(tabla[COL_ID])[COL_PRED].values
        if COL_PRED in df.columns else "",
        "Duracion_normal": tabla["Duracion"].values,
        "Duracion_minima": (tabla["Duracion"] * 0.6).round(1).values,
        "Costo_normal": df.set_index(COL_ID).reindex(tabla[COL_ID])[COL_COSTO].fillna(0).values
        if COL_COSTO in df.columns else 0.0,
        "Costo_acelerado": (df.set_index(COL_ID).reindex(tabla[COL_ID])[COL_COSTO].fillna(0) * 1.6).round(1).values
        if COL_COSTO in df.columns else 0.0,
    })

    editado = st.data_editor(
        base, use_container_width=True, hide_index=True, key="editor_crash",
        column_config={
            COL_ID: st.column_config.TextColumn("ID", disabled=True),
            COL_NOMBRE: st.column_config.TextColumn("Actividad", disabled=True),
            "Duracion_normal": st.column_config.NumberColumn("Dur. normal", format="%.1f"),
            "Duracion_minima": st.column_config.NumberColumn("Dur. mínima", format="%.1f"),
            "Costo_normal": st.column_config.NumberColumn("Costo normal", format="%.0f"),
            "Costo_acelerado": st.column_config.NumberColumn("Costo acelerado", format="%.0f"),
        },
    )

    prep = crashing.preparar(editado)
    st.subheader("2) Costo marginal y candidatas")
    cand = crashing.candidatas(editado, ruta)
    cc1, cc2 = st.columns([1.4, 1])
    with cc1:
        st.markdown("**Costo marginal (pendiente) por actividad**")
        st.dataframe(prep[[COL_ID, COL_NOMBRE, "Duracion_normal", "Duracion_minima",
                           "Reduccion_maxima", "Costo_marginal"]],
                     use_container_width=True, hide_index=True)
    with cc2:
        st.markdown("**Candidatas críticas (menor costo primero)**")
        if cand.empty:
            st.warning("No hay actividades críticas reducibles.")
        else:
            st.dataframe(cand[[COL_ID, "Costo_marginal", "Reduccion_maxima"]],
                         use_container_width=True, hide_index=True)

    st.divider()
    st.subheader("3) Optimización a duración objetivo (OR-Tools)")
    dmin = crashing._duracion_minima(prep)
    objetivo = st.slider("Duración objetivo del proyecto",
                         min_value=float(round(dmin, 1)), max_value=float(round(dur, 1)),
                         value=float(round((dur + dmin) / 2, 1)), step=0.5)

    if st.button("🚀 Optimizar (mínimo costo)", type="primary"):
        res = crashing.crash_lp(editado, duracion_objetivo=objetivo)
        if res["estado"] != "optimo":
            st.error(f"No factible: {res.get('detalle', '')} "
                     f"(mínimo posible ≈ {res.get('duracion_minima_posible', dmin):g})")
        else:
            k1, k2, k3 = st.columns(3)
            C.kpi_card(k1, "Duración lograda", f"{res['duracion_lograda']:g}",
                       f"antes: {dur:g}", tipo="ok")
            C.kpi_card(k2, "Reducción total", f"{dur - res['duracion_lograda']:g}", "unidades")
            C.kpi_card(k3, "Incremento de costo", f"+{res['costo_incremental']:,.0f}", tipo="warn")

            st.markdown("**Plan de aceleración**")
            st.dataframe(res["tabla"], use_container_width=True, hide_index=True)

            comp = pd.DataFrame({
                "Escenario": ["Normal", "Optimizado"],
                "Duración": [dur, res["duracion_lograda"]],
                "Costo aceleración": [0, res["costo_incremental"]],
            })
            st.markdown("**Comparativa antes / después**")
            st.dataframe(comp, use_container_width=True, hide_index=True)

    st.divider()
    st.subheader("4) Curva tiempo-costo completa (heurística iterativa)")
    if st.button("📈 Generar curva tiempo-costo"):
        curva = crashing.crash_heuristico(editado)
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=curva["Duracion"], y=curva["Costo_total"],
                                 mode="lines+markers", line=dict(color="#e63946", width=3),
                                 name="Costo total"))
        fig.update_layout(template="plotly_dark", height=420,
                          title="Curva tiempo-costo del proyecto",
                          xaxis_title="Duración del proyecto",
                          yaxis_title="Costo total acumulado")
        st.plotly_chart(fig, use_container_width=True)
        st.dataframe(curva, use_container_width=True, hide_index=True)
