"""Vistas de análisis: PERT, CPM y Ruta crítica."""
from __future__ import annotations

from datetime import datetime

import numpy as np
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
from scipy import stats

from core import cpm, pert
from io_utils import state
from viz import network_diagram, gantt
from . import components as C


# ---------------------------------------------------------------------------
# PERT
# ---------------------------------------------------------------------------
def analisis_pert():
    C.cabecera("📊 Análisis PERT", "Tiempo esperado, varianza y probabilidades")
    if not C.guard_actividades():
        return

    df = state.get_actividades()
    tabla = pert.calcular_pert(df)
    _, ruta, dur, _ = cpm.compute_cpm(df)
    est = pert.estadisticos_ruta(tabla, ruta)

    c1, c2, c3 = st.columns(3)
    C.kpi_card(c1, "Duración esperada (μ)", f"{est['media']:g}", "sobre ruta crítica", tipo="ok")
    C.kpi_card(c2, "Varianza del proyecto", f"{est['varianza']:g}")
    C.kpi_card(c3, "Desviación estándar (σ)", f"{est['desviacion']:g}")

    st.subheader("Resultados por actividad")
    st.dataframe(
        tabla.rename(columns={"Tiempo_esperado": "Tiempo esperado (TE)",
                              "Desviacion_estandar": "Desv. estándar"}),
        use_container_width=True, hide_index=True,
    )

    g1, g2 = st.columns(2)
    with g1:
        fig = px.bar(tabla, x="ID", y="Tiempo_esperado", color="Varianza",
                     color_continuous_scale="Reds",
                     title="Histograma de duración esperada por actividad",
                     labels={"Tiempo_esperado": "Tiempo esperado"})
        fig.update_layout(template="plotly_dark", height=380)
        st.plotly_chart(fig, use_container_width=True)

    with g2:
        mu, sigma = est["media"], max(est["desviacion"], 1e-6)
        x = np.linspace(mu - 4 * sigma, mu + 4 * sigma, 200)
        y = stats.norm.pdf(x, mu, sigma)
        fig2 = go.Figure(go.Scatter(x=x, y=y, fill="tozeroy", line=dict(color="#e63946")))
        fig2.add_vline(x=mu, line_dash="dash", line_color="white",
                       annotation_text=f"μ={mu:g}")
        fig2.update_layout(title="Distribución de probabilidad del proyecto",
                           template="plotly_dark", height=380,
                           xaxis_title="Duración", yaxis_title="Densidad")
        st.plotly_chart(fig2, use_container_width=True)

    st.subheader("Curva acumulada de probabilidad (S-curve)")
    mu, sigma = est["media"], max(est["desviacion"], 1e-6)
    x = np.linspace(mu - 4 * sigma, mu + 4 * sigma, 200)
    y = stats.norm.cdf(x, mu, sigma)
    figc = go.Figure(go.Scatter(x=x, y=y * 100, line=dict(color="#2a9d8f", width=3)))
    for pct, col in [(50, "#f4a261"), (80, "#e76f51"), (90, "#e63946")]:
        val = stats.norm.ppf(pct / 100, mu, sigma)
        figc.add_vline(x=val, line_dash="dot", line_color=col,
                       annotation_text=f"P{pct}={val:.1f}")
    figc.update_layout(template="plotly_dark", height=380,
                       xaxis_title="Duración", yaxis_title="Probabilidad acumulada (%)")
    st.plotly_chart(figc, use_container_width=True)

    st.info(
        f"La duración del proyecto se modela como normal con media **{mu:g}** y "
        f"desviación **{sigma:g}** (TLC sobre la ruta crítica). Para un análisis "
        "más realista use **Simulación Monte Carlo**."
    )


# ---------------------------------------------------------------------------
# CPM
# ---------------------------------------------------------------------------
def analisis_cpm():
    C.cabecera("🧮 Análisis CPM", "Tiempos tempranos/tardíos, holguras y red")
    if not C.guard_actividades():
        return

    df = state.get_actividades()
    try:
        tabla, ruta, dur, G = cpm.compute_cpm(df)
    except ValueError as e:
        st.error(str(e))
        return

    c1, c2, c3, c4 = st.columns(4)
    C.kpi_card(c1, "Duración del proyecto", f"{dur:g}", "unidades de tiempo", tipo="ok")
    C.kpi_card(c2, "Actividades", len(tabla))
    C.kpi_card(c3, "Actividades críticas", int(tabla["Critica"].sum()), tipo="crit")
    C.kpi_card(c4, "Holgura total acumulada", f"{tabla['Holgura_total'].sum():g}")

    st.subheader("Tabla CPM completa")
    styled = tabla.rename(columns={
        "Inicio_temprano": "IT (ES)", "Fin_temprano": "FT (EF)",
        "Inicio_tardio": "IL (LS)", "Fin_tardio": "FL (LF)",
        "Holgura_total": "H. Total", "Holgura_libre": "H. Libre",
    })

    def resaltar(row):
        if row["Critica"]:
            return ["background-color: #7a1420; color: white"] * len(row)
        return [""] * len(row)

    st.dataframe(styled.style.apply(resaltar, axis=1),
                 use_container_width=True, hide_index=True)

    st.subheader("Red PERT-CPM")
    st.plotly_chart(network_diagram.figura_red(G, ruta), use_container_width=True)


# ---------------------------------------------------------------------------
# RUTA CRÍTICA
# ---------------------------------------------------------------------------
def ruta_critica():
    C.cabecera("🎯 Ruta crítica", "Actividades sin holgura y diagrama de Gantt")
    if not C.guard_actividades():
        return

    df = state.get_actividades()
    tabla, ruta, dur, G = cpm.compute_cpm(df)
    cfg = state.get_config()

    st.markdown(f"### 🔴 Ruta crítica:  `{'  →  '.join(ruta)}`")
    col = st.columns(3)
    C.kpi_card(col[0], "Duración de la ruta crítica", f"{dur:g}", tipo="crit")
    C.kpi_card(col[1], "N.º de actividades críticas", len(ruta))
    C.kpi_card(col[2], "% del total", f"{100 * len(ruta) / max(len(tabla), 1):.0f}%")

    st.subheader("Actividades críticas")
    criticas = tabla[tabla["Critica"]]
    st.dataframe(criticas[["ID", "Actividad", "Duracion", "Inicio_temprano",
                           "Fin_temprano", "Holgura_total"]],
                 use_container_width=True, hide_index=True)

    st.subheader("Diagrama de Gantt")
    fecha = datetime.combine(cfg["fecha_inicio"], datetime.min.time())
    figg = gantt.construir_gantt(tabla, fecha, df, st.session_state.get("avance", {}))
    st.plotly_chart(figg, use_container_width=True)

    with st.expander("Gestionar % de avance por actividad"):
        avance = st.session_state.get("avance", {})
        cols = st.columns(4)
        for i, (_, r) in enumerate(tabla.iterrows()):
            with cols[i % 4]:
                avance[str(r["ID"])] = st.slider(
                    f"{r['ID']}", 0, 100, int(avance.get(str(r["ID"]), 0)),
                    key=f"av_{r['ID']}")
        st.session_state["avance"] = avance
